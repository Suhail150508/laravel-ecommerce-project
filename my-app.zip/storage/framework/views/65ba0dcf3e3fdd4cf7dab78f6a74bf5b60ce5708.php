<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> +017-98562848</a></li>
						<li><a href="suhail1054155@gmail.com"><i class="fa fa-envelope-o"></i> sohail1054155@gmail.com</a></li>

					</ul>
					<ul class="header-links pull-right">
						
                        <?php
                            $customer_id = Session::get('id');
                        ?>
                        <?php if( $customer_id != Null): ?>

                    <li>
                         <div class="dropdown">
							<a class="btn dropdown-toggle" data-toggle="dropdown" href="#"  style="color: white;background-color:black;border:none">
								<i class="fa fa-solid fa-user" style="color: white"></i><?php echo e(Session::get('name')); ?>


							</a>
							<ul class="dropdown-menu" >
								<li class="dropdown-menu-title">
 									<span style="background-color:black;padding:6px;color:white;width:50px;margin:3px">Account Settings</span>
								</li>
								<li><a   href="#" style="color: black;margin-top:5px"><i class="fa fa-user" aria-hidden="true"></i> Profile</a></li>
								<li><a   href="<?php echo e(url('/logout')); ?>" style="color: black;margin-top:5px"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a></li>
								<li><a   href="<?php echo e(url('# ')); ?>" style="color: black;margin-top:5px"><i class="fa fa-info-circle" aria-hidden="true"></i>Details</a></li>
							</ul>
						</div>
                    </li>
                        <?php else: ?>
                        <li><a href="<?php echo e(url('/login')); ?>"><i class="fa fa-user-o"></i> Login</a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(url('/register')); ?>"><i class="fa fa-user-o"></i> Sign-up</a></li>


					</ul>
				</div>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo" style="margin-right: 2rem">
								<a href="#" class="logo">
									<img src="./img/ecomm_logo.png" alt="" style="width: 60px;height:60px;border-radius:30px">
								</a>
							</div>
                            <h2 style="color: white;margin-top:1rem;">Shopping</h2>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
						<div class="col-md-6">
							<div class="header-search">

								<form action="<?php echo e(url('/search')); ?>" method="GET">
                                    <?php echo csrf_field(); ?>
									<select class="input-select" name="category">
										<option value="All"  <?php echo e(request('category') == 'All' ? 'selected' : ' '); ?>> All Categories</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($category->id); ?>"  <?php echo e(request('category') == $category->id ? 'selected' : ' '); ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<input class="input" name="product" placeholder="Search here" value="<?php echo e(request('product')); ?>">
								<button class="search-btn">Search</button>

								</form>
							</div>
						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<div>
									

                                    <?php

                                    $quantity = App\Models\Wishlist::where('user_ip',request()->ip())->sum('quantity');
                                ?>
									<a href="<?php echo e(url('/all_wishlist')); ?>">
										<i class="fa fa-heart-o"></i>
										<span>Your Wishlist</span>
										<div class="qty"><?php echo e($quantity); ?></div>
									</a>
								</div>
								<!-- /Wishlist -->

								<!-- Cart -->

								<div class="dropdown">
                                    <?php
                                    $total = App\Models\Cart::all()->where('user_ip',request()->ip())->sum(function($t){
                                      return  $t->quantity * $t->price ;
                                    });
                                    $quantity = App\Models\Cart::where('user_ip',request()->ip())->sum('quantity');
                                ?>
									<a href="<?php echo e(url('/all_carts')); ?>">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>
										<div class="qty"><?php echo e($quantity); ?></div>
									</a>
							</div>

							</div>
							</div>


						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
        </div>

			</header>

	<!-- NAVIGATION -->
    <nav id="navigation">
        <!-- container -->
        <div class="container">
            <!-- responsive-nav -->
            <div id="responsive-nav" style="margin-top: 2rem;font-size:2rem">
                <!-- NAV -->
                

                <ul class="main-nav nav navbar-nav">
                    <li ><a href="<?php echo e(url('/')); ?>"><h4>Home</h4></a></li>
                    <li ></li>
                    <li ><span style="color: white">.</span></li>
                    <li ><span style="color: white">.</span></li>
                    <li ><span style="color: white">.</span></li>
                    <li class="active"><a href="#"><h4>Categories: </h4></a></li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(url('/product_by_cat'.$category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li ><span style="color: white">.</span></li>
                    <li ><span style="color: white">.</span></li>
                    <li ><span style="color: white">.</span></li>
                    <li ><span style="color: white">.</span></li>
                    <li ><span style="color: white">.</span></li>
                    <li ><span style="color: white">.</span></li>

                    <li><a href="/admins"><h4>Admin</h4></a></li>
                </ul>

                <!-- /NAV -->
                <!-- /NAV -->
            </div>

            <!-- /responsive-nav -->
        </div>
        <!-- /container -->
    </nav>
    <!-- /NAVIGATION -->
<?php /**PATH C:\xampp\htdocs\my-app\resources\views/frontend/header.blade.php ENDPATH**/ ?>