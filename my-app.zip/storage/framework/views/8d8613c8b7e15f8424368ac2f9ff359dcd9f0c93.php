<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-4"></div>
    <div class="col-md-4">
    <div class="alert alert-success" role="alert" style="margin-top: 100px;margin-bottom: 50px;">
        <h3 class="alert-heading" style="text-align: center;">Well Done!</h3>
        <h4 style="text-align: center;">You have successfully placed order</h4>

        <hr>
        <p class="mb-0" style="text-align: center;">We will contact you soon.</p>
    </div>
    </div>
    <div class="col-md-4"></div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-app\resources\views/frontend/pages/well_done.blade.php ENDPATH**/ ?>