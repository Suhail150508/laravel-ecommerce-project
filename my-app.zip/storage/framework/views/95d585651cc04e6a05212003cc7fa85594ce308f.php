<?php $__env->startSection('content'); ?>

<div class="row mt-5" style="margin-top: 3rem">

    <div class="span4">

    </div>
    <div class="span8">

<div class="prodcut " >

<form action="<?php echo e(url('/products/')); ?>" method="post" enctype="multipart/form-data">
   <?php echo csrf_field(); ?>

    <div class="form-group">
      <label for="name">Code</label>
      <input type="text" class="form-control" name="code"  placeholder="code">
    </div>
    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error" style="color:red"><?php echo e($message); ?></div>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="form-group">
      <label for="name">Name</label>
      <input type="text" class="form-control" name="name"  placeholder="name">
    </div>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error" style="color:red"><?php echo e($message); ?></div>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

     <div class="form-group">
        <label for="name">Category</label>
        <div class="control">
            <select name="category" style="margin-left:20px">
            <option> Select Category</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
      </div>

      <div class="form-group">
        <label for="name">SubCategory</label>
        <div class="control">
            <select name="subcategory" style="margin-left:20px">
            <option> Select SubCategory</option>
            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
      </div>

      <div class="form-group">
        <label for="name">Brand</label>
        <div class="control">
            <select name="brand" style="margin-left:20px">
            <option> Select Brand</option>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
      </div>

      <div class="form-group">
        <label for="name">Unit</label>
        <div class="control">
            <select name="unit" style="margin-left:20px">
            <option> Select Unit</option>
            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
      </div>

      <div class="form-group">
        <label for="name">Size</label>
        <div class="control">
            <select name="size" id="input" data-role="tagsinput" style="margin-left:20px">
            <option> Select Size</option>
            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($size->id); ?>"><?php echo e(implode(',',Json_decode($size->size))); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
      </div>

      <div class="form-group">
        <label for="name">Color</label>
        <div class="control">
            <select name="color" id="input" data-role="tagsinput" style="margin-left:20px">
            <option> Select Color</option>
            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($color->id); ?>"><?php echo e(implode(',',Json_decode($color->color))); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
      </div>

    <div class="form-group">
      <label for="description">Description</label>
      <textarea  class="form-control cleditor" name="description" placeholder="description"></textarea>
    </div>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error" style="color:red"><?php echo e($message); ?></div>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

     <div class="form-group">
        <label for="name">Price</label>
        <input type="text" class="form-control" name="price"  placeholder="price">
      </div>
      <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="error" style="color:red"><?php echo e($message); ?></div>
       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="form-group ">
      <label for="image">image</label>
      <input type="file" class="form-control" name="file[]" multiple required>
    </div>
    <?php $__errorArgs = ['file[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error" style="color:red"><?php echo e($message); ?></div>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <button type="submit" class="btn btn-primary">Add Product</button>
  </form>

  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-app\resources\views/admin/product/create.blade.php ENDPATH**/ ?>