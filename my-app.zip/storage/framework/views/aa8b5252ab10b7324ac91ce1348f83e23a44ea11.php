;

<?php $__env->startSection('content'); ?>




                <!--/span-->
<div class=" row main_content container ml-5" style="margin:2rem 16rem;width:80%">



			

			<div class="row-fluid">
                <a class="quick-button metro blue span2" href="<?php echo e(url('/order')); ?>">
					<i class="icon-shopping-cart"></i>
				<p>Orders</p>
					<span class="badge">13</span>
				</a>
                <a class="quick-button metro green span2"href="<?php echo e(url('/products')); ?>">
					<i class="icon-barcode"></i>
					<p>Products</p>
				</a>
				<a class="quick-button metro yellow span2">
					<i class="icon-group"></i>
					<p>Users</p>
					<span class="badge">237</span>
				</a>
				<a class="quick-button metro red span2" href="#">
					<i class="icon-comments-alt"></i>
					<p>Invoice</p>
					<span class="badge">46</span>
				</a>


				
				<a class="quick-button metro black span2">
					<i class="icon-calendar"></i>
					<p>Calendar</p>
				</a>

				<div class="clearfix"></div>

			</div>
            </div>
            <!--/row-->
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>