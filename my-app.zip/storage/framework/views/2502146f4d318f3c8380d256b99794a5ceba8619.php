<?php $__env->startSection('content'); ?>

<!-- Order Details -->
<?php
$total_price= App\Models\Cart::all()->where('user_ip',request()->ip())->sum(function($t){
return  $t->quantity * $t->price;
   });
$total_quantity= App\Models\Cart::all()->where('user_ip',request()->ip())->sum('quantity');
   ?>
<div class="row">


<div class="col-md-4"></div>
<div class=" col-md-4 order-details">
    <div class="section-title text-center">
        <h3 class="title">Your Order</h3>
    </div>
    <div class="order-summary">
        <div class="order-col">
            <div><strong>PRODUCT</strong></div>
            <div><strong>TOTAL</strong></div>
        </div>

        <div class="order-products">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="order-col">
           <div><?php echo e($datas->quantity); ?>*<?php echo e($datas->product->name); ?></div>
           <div><?php echo e($datas->price* $datas->quantity); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="order-col">
                <div>Total Price</div>
                <div>&#2547; <?php echo e($total_price); ?></div>
            </div>

        </div>
        <div class="order-col">
            <div>Shiping</div>
            <div><strong>&#2547; 50</strong></div>
        </div>
        <?php
        $total= $total_price + 50;
    ?>
        <div class="order-col">
            <div><strong>TOTAL</strong></div>
            <div><strong class="order-total">&#2547; <?php echo e($total); ?></strong></div>
        </div>
    </div>
    <?php
    $customer_id = Session::get('id');

?>
    <form action="<?php echo e(url('/order_place'.$customer_id->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
<div class="section-title text-center" style="margin-top:50px">
    <h4 class="title" style="color:#D10024"> Please select the payment method</h4>
</div>

    <div class="payment-method">
        <div class="input-radio">
            <input type="radio" name="payment" id="payment-1" value="cash">
            <label for="payment-1">
                <span></span>
                Cash on delivery
            </label>
            <div class="caption">
                <p>You can also select cash on delivery.</p>
            </div>
        </div>
        <div class="input-radio">
            <input type="radio" name="payment" id="payment-2" value="Bkash">
            <label for="payment-2">
                <span></span>
                Bkash
            </label>
            <div class="caption">
                <p>Bkash No: 01798562848.</p>
            </div>
        </div>
        <div class="input-radio">
            <input type="radio" name="payment" id="payment-3" value="Nogod">
            <label for="payment-3">
                <span></span>
                Nogod
            </label>
            <div class="caption">
                <p>Nogod No:01798562848.</p>
            </div>
        </div>
    </div>
    <div class="input-checkbox">
        <input type="checkbox" id="terms">
        <label for="terms">
            <span></span>
            I've read and accept the <a href="#">terms & conditions</a>
        </label>
    </div>
  <input type="submit" class="primary-btn order-submit" value="Place Order" style="float: right">
</div>
</form>

<div class="col-md-4"></div>
</div>

<!-- /Order Details -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-app\resources\views/frontend/pages/payment.blade.php ENDPATH**/ ?>