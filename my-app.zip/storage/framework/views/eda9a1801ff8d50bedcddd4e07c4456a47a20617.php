<?php $__env->startSection('content'); ?>

<div class="cart_order" style="margin:2rem 16rem;width:80%">

    <table class="table" style="margin:0 auto;padding:0 10rem">
        <thead>
          <tr>
            <th style="width: 20%">Product</th>
            <th style="width: 10%">Price</th>
            <th style="width: 30%">Quantity</th>
            <th style="width: 15%">Total</th>
            <th style="width: 15%">actions</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
            $cart->product['image'] = explode("|", $cart->product->image);

            $images = $cart->product->image[0];
     ?>
          <tr>
            <td scope="row">
                <img src="<?php echo e(asset('/image/'.$images )); ?>" alt="" style="width: 50px;height:50px">
            </td>
            <td>&#2547; <?php echo e($cart->price); ?></td>
            <td>
              <div class="quantity">
             <form action="<?php echo e(url('/quantity_update'.$cart->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="pro-quantity">
                  <input type="text" name ="quantity" value="<?php echo e($cart->quantity); ?>" min="1">
            <button type="submit" class="btn btn-success">update</button>
                </div>
            </form>
              </div>
              
            </td>
            <td>&#2547; <?php echo e($cart->quantity * $cart->price); ?></td>
            <td>
              <a href="<?php echo e(url('/delete_item'.$cart->id)); ?>"> <button class="btn btn-danger">Delete</button></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

    </div>


    <?php
 $total_price= App\Models\Cart::all()->where('user_ip',request()->ip())->sum(function($t){
 return  $t->quantity * $t->price;
    });
 $total_quantity= App\Models\Cart::all()->where('user_ip',request()->ip())->sum('quantity');
    ?>
    <div class="chechkOut" style="background-color:gray;width:40%;margin:0 auto;margin-top:15rem;margin-bottom:7rem;background-color:rgb(156, 242, 141)">
    <h1 style="text-align: center;padding-top:3rem">Cart Total</h1>
    <div class="total" style="display: flex; justify-content:space-between;width:70%;margin:0 auto;margin-top:5rem;margin-bottom:5rem">
        <h3>Total-Quantity</h3>
        <h3><?php echo e($total_quantity); ?></h3>

    </div>
    <div class="total" style="display: flex; justify-content:space-between;width:70%;margin:0 auto;margin-top:5rem;margin-bottom:5rem">

        <h3>Total-Price </h3>
        <h3>&#2547; <?php echo e($total_price); ?></h3>
    </div>
    <?php
    $customer_id = Session::get('id');
?>
<?php if( $customer_id != Null): ?>
<a class="btn btn-primary" href="<?php echo e(url('/checkout')); ?>" style="padding:.6rem ; margin-left:16rem;font-size:2.5rem;margin-bottom:2rem;">Check Out</a>
<?php else: ?>
<a class="btn btn-primary" href="<?php echo e(url('/login')); ?>" style="padding:.6rem ; margin-left:16rem;font-size:2.5rem;margin-bottom:2rem;">Check Out</a>
<?php endif; ?>
</div>

          <tbody>
            <tr>
              <td></td>
              <td></td>
            </tr>

          </tbody>
      </div>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-app\resources\views/admin/cart/all_cart.blade.php ENDPATH**/ ?>