<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>


     
     <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">


 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.1/js/bootstrap.min.js" integrity="sha512-fHY2UiQlipUq0dEabSM4s+phmn+bcxSYzXP4vAXItBvBHU7zAM/mkhCZjtBEIJexhOMzZbgFlPLuErlJF2b+0g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


</head>
<body>





    <div class="row mt-5" style="margin-top: 3rem">

        <div class="span4">

        </div>
        <div class="span8">

    <div class="create_catagory " >

    <form action="<?php echo e(url('/sub_categories')); ?>" method="post" enctype="multipart/form-data">
       <?php echo csrf_field(); ?>

        <div class="form-group">
          <label for="name">Name</label>
          <input type="text" class="form-control" name="name"  placeholder="name">
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error" style="color:red"><?php echo e($message); ?></div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

         <div class="form-group">
            <label for="name">Category</label>
            <div class="control">
                <select name="category" style="margin-left:20px">
                <option> Select Category</option>
                <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
          </div>

        <div class="form-group">
          <label for="description">Description</label>
          <textarea  class="form-control cleditor" name="description" placeholder="description"></textarea>
        </div>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error" style="color:red"><?php echo e($message); ?></div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

         <div class="form-group ">
            <label for="image">image</label>
            <input type="file" class="form-control" name="image" placeholder="image">
          </div>

        <button type="submit" class="btn btn-primary">Add-Subcategory</button>
      </form>

      </div>
    </div>
    </div>


    <script>
        <?php if(Session::has('message')): ?>

    toastr.options={
         'clossButton':true,
         'progressBar':true
    }
    toastr.success("<?php echo e(Session::get('message')); ?>"
    , 'Success! New Student added'
    );

    // toastr.warnig("<?php echo e(Session::get('message')); ?>"
    // , 'Success! New Student added'
    // );

           <?php endif; ?>
       </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\my-app\resources\views/admin/toastr.blade.php ENDPATH**/ ?>