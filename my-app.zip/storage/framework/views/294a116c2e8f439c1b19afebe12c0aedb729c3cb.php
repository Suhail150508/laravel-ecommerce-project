<?php $__env->startSection('content'); ?>

<div class="row all_products" style="margin:2rem 16rem;width:80%">
    

    <div class="box-content">
        <table class="table table-striped table-bordered bootstrap-datatable datatable">
          <thead>
              <tr>
                  <th>Id</th>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Images</th>
                  <th>price</th>
                  <th>Status</th>
                  <th>Actions</th>
              </tr>
          </thead>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $product['image'] = explode("|",$product->image);
        ?>
          <tbody>

            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->code); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->description); ?></td>
                <td>
                    <?php $__currentLoopData = $product->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('/image/'. $images)); ?>" alt="img" style="width: 60px">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </td>
                <td> &#2547: <?php echo e($product->price); ?></td>

                <td>
                    <?php if($product->status==1): ?>
                    <span class="label label-important">Active</span>
                    <?php else: ?>
                    <span class="label label-secondary">Deactive</span>
                    <?php endif; ?>
                </td>
       
                <td class="row">
                    <div class="span3"></div>

                    <div class="span2">

         <?php if($product->status==1): ?>

              <a class="btn btn-success" href="<?php echo e(url('/products'.$product->id)); ?>" >
                <i class="halflings-icon white thumbs-down"></i>
            </a>

            <?php else: ?>

            <a class="btn btn-danger" href="<?php echo e(url('/products'.$product->id)); ?>" >
                <i class="halflings-icon white thumbs-up"></i>
            </a>
            <?php endif; ?>
            </div>


               <div class="span2">

                    <a class="btn btn-info" href="<?php echo e(url('/products/'.$product->id.'/edit')); ?>" style="margin-left: 1rem">
                        <i class="halflings-icon white edit"></i>
                    </a>
                </div>

                    <div class="span2">
                        <form method="post" action="<?php echo e(url('/products/'.$product->id )); ?>" style="margin-left: 1rem">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"> <i class="halflings-icon white trash"></i></button>

                        </form>
                    </div>

                    <div class="span3"></div>
                </td>
            </tr>


          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-app\resources\views/admin/product/all_product.blade.php ENDPATH**/ ?>