<?php $__env->startSection('content'); ?>

<div class="cart_order" style="margin:2rem 16rem;width:80%">

    <table class="table" style="margin:0 auto;padding:0 10rem">
        <thead>
          <tr>
            <th style="width: 20%">Product</th>
            <th style="width: 10%">Price</th>
            <th style="width: 30%">Quantity</th>
            <th style="width: 15%">Total</th>
            <th style="width: 15%">actions</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
            $wishlist->product['image'] = explode("|", $wishlist->product->image);

            $images = $wishlist->product->image[0];
     ?>
          <tr>
            <td scope="row">
                <img src="<?php echo e(asset('/image/'.$images )); ?>" alt="" style="width: 50px;height:50px">
            </td>
            <td>&#2547; <?php echo e($wishlist->price); ?></td>
            <td>

              <?php echo e($wishlist->quantity); ?>

            </td>
            <td>&#2547; <?php echo e($wishlist->quantity * $wishlist->price); ?></td>
            <td>
              <a href="<?php echo e(url('/delete_wishlist'.$wishlist->id)); ?>"> <button class="btn btn-danger">Delete</button></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

    </div>



</div>

          <tbody>
            <tr>
              <td></td>
              <td></td>
            </tr>

          </tbody>
      </div>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-app\resources\views/admin/cart/wishlist.blade.php ENDPATH**/ ?>