<?php $__env->startSection('content'); ?>
    <div class="row-fluid sortable" style="margin: 2rem 16rem;width:90%">
        <div class="box span12">
            <div class="box-header" data-original-title>
                <p class="alert-success">
                    <?php

                    $message = Session::get('message');
                    if ($message) {
                        echo $message;
                        Session::put('message', null);
                    }
                    ?>
                </p>

            </div>


            <div class="box-content">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer Name</th>
                            
                            <th>Order Date & Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>




                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tbody>
                            <tr>
                                <td><?php echo e($order->id); ?></td>

                                <td class="center"><?php echo e($order->Customer->name); ?></td>
                                
                                <td class="center"><?php echo e(\Carbon\Carbon::now()); ?></td>

                                <td class="center">
<div>
    <form action="<?php echo e(url('/orders/'.$order->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-danger"> <i class="halflings-icon white trash"></i></button>
    </form>
</div>
                                    

                                    
                                    <a class="btn btn-success " href="<?php echo e(url('/order_details/' . $order->id)); ?>"> Details_info
                                    </a>

                                </td>
                            </tr>

                        </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    


                </table>


            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my-app\resources\views/admin/order/order.blade.php ENDPATH**/ ?>