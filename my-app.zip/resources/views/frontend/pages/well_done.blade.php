@extends('frontend.master')
@section('content')
<div class="row">
<div class="col-md-4"></div>
    <div class="col-md-4">
    <div class="alert alert-success" role="alert" style="margin-top: 100px;margin-bottom: 50px;">
        <h3 class="alert-heading" style="text-align: center;">Well Done!</h3>
        <h4 style="text-align: center;">You have successfully placed order</h4>

        <hr>
        <p class="mb-0" style="text-align: center;">We will contact you soon.</p>
    </div>
    </div>
    <div class="col-md-4"></div>

</div>

@endsection
